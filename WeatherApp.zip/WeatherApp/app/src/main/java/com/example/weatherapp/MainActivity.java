package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {
    Button confirm;
    EditText zipCodeText;
    String zipCode;
    String jsonString = "";

    TextView mainDate;
    TextView mainTempText;
    ImageView mainImageView;
    TextView mainTime;
    TextView mainDescription;
    TextView givenPhrase;

    TextView leftDateText;
    TextView leftHighText;
    TextView leftLowText;
    ImageView leftImage;
    TextView leftTime;

    TextView midLeftDateText;
    TextView midleftHighText;
    TextView midLeftLowText;
    ImageView midLeftImage;
    TextView midLeftTime;

    TextView midRightDateText;
    TextView midRightHighText;
    TextView midRightLowText;
    ImageView midRightImage;
    TextView midRightTime;

    TextView rightDateText;
    TextView rightHighText;
    TextView rightLowText;
    ImageView rightImage;
    TextView rightTime;


    JSONObject weatherData;
    JSONArray weatherArray;
    
    private class DataTask extends AsyncTask<String, Void, JSONObject>
    {
        
        @Override
        protected JSONObject doInBackground(String... strings) {
            zipCode = strings[0];
            try {
                URL url = new URL("https://api.openweathermap.org/data/2.5/forecast?zip=" + zipCode + ",US&units=imperial&cnt=5&appid=b60777996258651c9b28a341ceab2a02");
                URLConnection urlConnection = url.openConnection();
                InputStream inputStream = urlConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String line = "";
                jsonString = bufferedReader.readLine();
                while((line = bufferedReader.readLine()) != null)
                {
                    jsonString += line;
                }
                weatherData = new JSONObject(jsonString);


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return weatherData;
        }

        protected void onPostExecute(JSONObject weatherData) {
            try {

                weatherArray = weatherData.getJSONArray("list");
                mainDate.setText(getDate(0));
                mainTempText.setText(getMainTemp(0));
                mainDescription.setText(getCatchphrase(0));
                mainImageView.setImageResource(getImage(0));
                mainTime.setText(getTime(0));
                givenPhrase.setText(getGivenPhrase(0));

                leftDateText.setText((getDate(1)));
                leftHighText.setText(getHighTemp(1));
                leftLowText.setText(getLowTemp(1));
                leftImage.setImageResource(getImage(1));
                leftTime.setText(getTime(1));

                midLeftDateText.setText((getDate(2)));
                midleftHighText.setText(getHighTemp(2));
                midLeftLowText.setText(getLowTemp(2));
                midLeftImage.setImageResource(getImage(2));
                midLeftTime.setText(getTime(2));

                midRightDateText.setText((getDate(3)));
                midRightHighText.setText(getHighTemp(3));
                midRightLowText.setText(getLowTemp(3));
                midRightImage.setImageResource(getImage(3));
                midRightTime.setText(getTime(3));


                rightDateText.setText((getDate(4)));
                rightHighText.setText(getHighTemp(4));
                rightLowText.setText(getLowTemp(4));
                rightImage.setImageResource(getImage(4));
                rightTime.setText(getTime(4));


            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        confirm = findViewById(R.id.id_confirm);
        zipCodeText = findViewById(R.id.id_editZip);

        mainDate = findViewById(R.id.id_mainDate);
        mainTempText = findViewById(R.id.id_mainTempText);
        mainImageView = findViewById(R.id.id_mainImageView);
        mainTime = findViewById(R.id.id_mainTime);
        mainDescription = findViewById(R.id.id_mainDescription);
        givenPhrase = findViewById(R.id.id_givenPhrase);

        leftDateText = findViewById(R.id.id_LeftDateText);
        leftHighText = findViewById(R.id.id_LeftHighText);
        leftLowText = findViewById(R.id.id_LeftLowText);
        leftImage = findViewById(R.id.id_LeftImageView);
        leftTime = findViewById(R.id.id_leftTime);

        midLeftDateText = findViewById(R.id.id_midLeftDateText);
        midleftHighText = findViewById(R.id.id_midLeftHighText);
        midLeftLowText = findViewById(R.id.id_MidLeftLowText);
        midLeftImage = findViewById(R.id.id_midLeftImageView);
        midLeftTime = findViewById(R.id.id_midLeftTime);

        midRightDateText = findViewById(R.id.id_midRightDateText);
        midRightHighText = findViewById(R.id.id_midRightHighText);
        midRightLowText = findViewById(R.id.id_MidRightLowText);
        midRightImage = findViewById(R.id.id_midRightImageView);
        midRightTime = findViewById(R.id.id_midRightTime);

        rightDateText = findViewById(R.id.id_RightDateText);
        rightHighText = findViewById(R.id.id_RightHighText);
        rightLowText = findViewById(R.id.id_RightLowText);
        rightImage = findViewById(R.id.id_RightimageView);
        rightTime = findViewById(R.id.id_rightTime);

        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DataTask async = new DataTask();
                async.execute(zipCodeText.getText().toString());
            }
        });



    }
    public String getGivenPhrase(int index) throws JSONException
    {
        JSONObject day = weatherArray.getJSONObject(index);
        JSONArray weather = day.getJSONArray("weather");
        JSONObject zero = weather.getJSONObject(0);
        return zero.getString("description");
    }

    public String getDate(int index) throws JSONException
    {
        JSONObject day = weatherArray.getJSONObject(index);
        long dt = day.getLong("dt");
        dt *= 1000;

        Date date = new Date(dt);
        DateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm");
        format.setTimeZone(TimeZone.getTimeZone("EST"));
        String formatted = format.format(date);
        int indexSpace = formatted.indexOf(" ");
        return formatted.substring(0,indexSpace);
    }
    
    public String getHighTemp(int index) throws JSONException
    {
        JSONObject day = weatherArray.getJSONObject(index);
        JSONObject main = day.getJSONObject("main");
        double high = main.getDouble("temp_max");
        return "High: " + (int)Math.round(high);

    }
    public String getLowTemp(int index) throws JSONException
    {
        JSONObject day = weatherArray.getJSONObject(index);
        JSONObject main = day.getJSONObject("main");
        double low = main.getDouble("temp_min");
        return "low: " + (int)Math.round(low);

    }
    public String getMainTemp(int index) throws JSONException
    {
        JSONObject day = weatherArray.getJSONObject(index);
        JSONObject main = day.getJSONObject("main");
        double temp  = main.getDouble("temp");
        return "Temp: " + (int)Math.round(temp);
    }
    public String getTime(int index) throws JSONException
    {
        JSONObject day = weatherArray.getJSONObject(index);
        long dt = day.getLong("dt");
        dt *= 1000;

        Date date = new Date(dt);
        DateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm");
        format.setTimeZone(TimeZone.getTimeZone("EST"));
        String formatted = format.format(date);

        int indexSpace = formatted.indexOf(" ");
        return formatted.substring(indexSpace);

    }

    public int getImage(int index) throws JSONException {
        JSONObject day = weatherArray.getJSONObject(index);
        JSONArray weather = day.getJSONArray("weather");
        JSONObject zero = weather.getJSONObject(0);
        int id = zero.getInt("id");
        switch (id) {
            case 200:
            case 201:
            case 202:
            case 210:
            case 212:
            case 221:
            case 211:
            case 231:
            case 232:
            case 230:

                return R.drawable.thunderstorm;
            case 300:
            case 301:
            case 302:
            case 310:
            case 311:
            case 312:
            case 313:
            case 314:
            case 321:
                return R.drawable.drizzle;
            case 500:
            case 501:
            case 502:
            case 503:
            case 504:
            case 520:
            case 521:
            case 522:
            case 531:
                return R.drawable.rain;
            case 511:
            case 600:
            case 601:
            case 602:
            case 611:
            case 612:
            case 613:
            case 615:
            case 616:
            case 620:
            case 621:
            case 622:
                return R.drawable.snow;
            case 701:
            case 711:
            case 721:
            case 731:
            case 741:
            case 751:
            case 761:
            case 762:
            case 771:
            case 781:
                return R.drawable.mist;
            case 800:
                return R.drawable.clearsky;
            case 801:
                return R.drawable.zerotwo;
            case 802:
                return R.drawable.zerothree;
            case 803:
            case 804:
                return R.drawable.zerofour;

        }
        return R.drawable.clearsky;
    }

    public String getCatchphrase(int index) throws JSONException {
        JSONObject day = weatherArray.getJSONObject(index);
        JSONArray weather = day.getJSONArray("weather");
        JSONObject zero = weather.getJSONObject(0);
        int id = zero.getInt("id");
        switch (id) {
            case 200:
            case 201:
            case 202:
            case 210:
            case 212:
            case 221:
            case 211:
            case 231:
            case 232:
            case 230:
                return "There's something in the air. Something's coming. A storm's approaching...";
            case 300:
            case 301:
            case 302:
            case 310:
            case 311:
            case 312:
            case 313:
            case 314:
            case 321:
                return "Someday a real rain'll come and wash all this scum off the streets.";
            case 500:
            case 501:
            case 502:
            case 503:
            case 504:
            case 520:
            case 521:
            case 522:
            case 531:
                return "One day, it started raining, and it didn't quit for four months";
            case 511:
            case 600:
            case 601:
            case 602:
            case 611:
            case 613:
            case 615:
            case 616:
            case 620:
            case 621:
            case 622:
                return "Do you wanna build a snowman? It doesn't have to be a snowman - Frozen";
            case 612:
                return "Okay, rule number one out here. Always... No. Never go out in a blizzard.";
            case 701:
            case 711:
            case 721:
            case 731:
            case 741:
            case 751:
            case 761:
            case 762:
            case 771:
            case 781:
                return "This fog's as thick as... -Jellied brains. -Or thicker!";
            case 800:
                return "Hey, did you see that sky today? Talk about blue.";
            case 801:
                return "Oh, come on! Come on! Where are you? You're in the clouds, and we are in a basement!";
            case 802:
                return "Clouds are like dreams floating across a sky-blue mind.";
            case 803:
            case 804:
                return "Those clouds don't scare me. They can't disguise this magic that's happened right before my eyes..";
        }
        return "catchphrase";
    }
    
     
}